# Develop Environments
## Version
1. Spring Boot Version : 3.0.5
2. JDK : 17
3. MySQL : 8
4. Build configuration
   - local: build in Spring Boot Terminal
   - server: Jenkins, docker


GIT TEST