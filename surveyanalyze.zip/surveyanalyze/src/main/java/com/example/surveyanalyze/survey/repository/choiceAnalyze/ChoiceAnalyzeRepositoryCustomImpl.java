package com.example.surveyanalyze.survey.repository.choiceAnalyze;

import org.springframework.stereotype.Repository;

@Repository
public class ChoiceAnalyzeRepositoryCustomImpl implements ChoiceAnalyzeRepositoryCustom {
}
