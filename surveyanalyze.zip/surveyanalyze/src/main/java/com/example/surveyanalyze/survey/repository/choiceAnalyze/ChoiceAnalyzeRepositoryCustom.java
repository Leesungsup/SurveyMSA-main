package com.example.surveyanalyze.survey.repository.choiceAnalyze;

public interface ChoiceAnalyzeRepositoryCustom {
}
