package com.example.surveyanalyze.survey.repository.questionAnlayze;

import org.springframework.stereotype.Repository;

@Repository
public class QuestionAnalyzeRepositoryCustomImpl implements QuestionAnalyzeRepositoryCustom {
}
