package com.example.surveyanalyze;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurveyAnalyzeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurveyAnalyzeApplication.class, args);
	}

}
