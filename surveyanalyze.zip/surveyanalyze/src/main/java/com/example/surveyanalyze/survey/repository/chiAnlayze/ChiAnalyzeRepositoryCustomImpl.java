package com.example.surveyanalyze.survey.repository.chiAnlayze;

import org.springframework.stereotype.Repository;

@Repository
public class ChiAnalyzeRepositoryCustomImpl implements ChiAnalyzeRepositoryCustom {
}
