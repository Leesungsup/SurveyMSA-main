package com.example.surveyanalyze.survey.repository.chiAnlayze;

public interface ChiAnalyzeRepositoryCustom {
}
