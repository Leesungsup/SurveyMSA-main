package com.example.surveyanalyze.survey.repository.questionAnlayze;

public interface QuestionAnalyzeRepositoryCustom {
}
