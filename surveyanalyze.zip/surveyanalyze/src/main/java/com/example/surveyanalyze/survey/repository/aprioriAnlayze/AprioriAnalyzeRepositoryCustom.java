package com.example.surveyanalyze.survey.repository.aprioriAnlayze;

public interface AprioriAnalyzeRepositoryCustom {
}
