package com.example.surveyanalyze.survey.repository.surveyAnalyze;

import org.springframework.stereotype.Repository;

@Repository
public class SurveyAnalyzeCustomImpl implements SurveyAnalyzeRepositoryCustom {
}
