package com.example.surveyanalyze.survey.repository.compareAnlayze;

import org.springframework.stereotype.Repository;

@Repository
public class CompareAnalyzeRepositoryCustomImpl implements CompareAnalyzeRepositoryCustom {
}
