package com.example.surveyanalyze.survey.repository.surveyAnalyze;

public interface SurveyAnalyzeRepositoryCustom {
}
