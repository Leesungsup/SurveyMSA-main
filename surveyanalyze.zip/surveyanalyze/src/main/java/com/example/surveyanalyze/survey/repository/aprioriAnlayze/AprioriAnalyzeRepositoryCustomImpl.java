package com.example.surveyanalyze.survey.repository.aprioriAnlayze;

import org.springframework.stereotype.Repository;

@Repository
public class AprioriAnalyzeRepositoryCustomImpl implements AprioriAnalyzeRepositoryCustom {
}
