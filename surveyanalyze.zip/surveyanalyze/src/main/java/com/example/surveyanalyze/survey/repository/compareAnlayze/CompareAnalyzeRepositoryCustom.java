package com.example.surveyanalyze.survey.repository.compareAnlayze;

public interface CompareAnalyzeRepositoryCustom {
}
