package com.example.surveyanalyze;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveyanalyzeApplicationTests {

}
