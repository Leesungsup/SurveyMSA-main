package com.example.surveyanswer.survey.repository.questionAnswer;

public interface QuestionAnswerRepositoryCustom {
}
