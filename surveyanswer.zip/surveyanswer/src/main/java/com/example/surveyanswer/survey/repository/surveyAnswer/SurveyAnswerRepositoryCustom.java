package com.example.surveyanswer.survey.repository.surveyAnswer;

public interface SurveyAnswerRepositoryCustom {

}
