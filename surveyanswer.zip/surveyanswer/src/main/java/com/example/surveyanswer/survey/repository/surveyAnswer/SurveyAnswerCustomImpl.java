package com.example.surveyanswer.survey.repository.surveyAnswer;

import org.springframework.stereotype.Repository;

@Repository
public class SurveyAnswerCustomImpl implements SurveyAnswerRepositoryCustom {
}
