package com.example.surveyanswer.survey.repository.questionAnswer;

import org.springframework.stereotype.Repository;

@Repository
public class QuestionAnswerCustomImpl implements QuestionAnswerRepositoryCustom {
}
