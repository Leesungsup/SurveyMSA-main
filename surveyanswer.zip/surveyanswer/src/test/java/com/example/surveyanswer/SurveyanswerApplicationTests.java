package com.example.surveyanswer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveyanswerApplicationTests {

}
